document.getElementById("save").addEventListener("click", () => {
  var isEnabled = document.getElementById("isEnabled").checked;

  localStorage["input_phone_number_enabled"] = isEnabled;

  chrome.storage.sync.set({ input_phone_number_enabled: isEnabled }, () => {
    console.log("Settings saved: ", isEnabled);
  });
});

document.getElementById("erase").addEventListener("click", () => {
  localStorage.removeItem("input_phone_number_enabled");
  location.reload();
});

document.addEventListener("DOMContentLoaded", () => {
  const isEnabled =
    localStorage["input_phone_number_enabled"] === "true" ? true : false;
  document.getElementById("isEnabled").checked = isEnabled;
});
